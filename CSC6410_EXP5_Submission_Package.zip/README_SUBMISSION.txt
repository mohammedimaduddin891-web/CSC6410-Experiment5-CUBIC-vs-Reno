CSC 6410 EXPERIMENT 5 - SUBMISSION PACKAGE

REPORT: CSC6410_EXP5_ImadUddin.docx
PRIMARY DATA: raw/results.zip (30 single-flow iperf3 JSON measurements)
FAIRNESS DATA: raw/result2.zip (two 60-second concurrent-flow tests)
RECOVERED FILE: raw/reno_loss1_trial3_netem.txt (not present in original results.zip)
SCRIPTS: scripts/exp5_collect.py, scripts/exp5_fairness.py, scripts/exp5_analyze.py
ANALYSIS: analysis/throughput_summary.csv and two figures

Evidence measured in native Ubuntu WSL2 Mininet; BBR not available; Reno used as permitted fallback.
The report contains student-captured evidence and raw-value excerpts.
IMPORTANT BEFORE SUBMISSION: upload reviewed scripts/data to your own GitHub repository and insert its VERIFIED URL in the report or submission form. Do not claim a GitHub link that does not exist.
If a separate AI Report 5 is required, submit it as a separate deliverable.
